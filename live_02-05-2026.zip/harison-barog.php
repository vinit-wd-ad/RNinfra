<!DOCTYPE html>
<html lang="en">

<head>
  <?php include "include/head.php" ?>
  <title>Harison Group Residences · Barog, H.P. | Soft Launch | Rising Nexus Infra</title>
  <meta name="description"
    content="Premium 1-BHK Residences by Harison Group in Barog, H.P. Starting from ₹81 Lakh. SBI & HDFC Approved. Exclusively by Rising Nexus Infra. RERA: HPRERASOL 2024119/P" />

</head>

<body class="font-sans bg-rbg text-rtxt leading-[1.75]">

  <!-- ════════════════════════════════════════════════════════════════════════
     FLOATING ACTION BUTTONS
  ════════════════════════════════════════════════════════════════════════════ -->
  <div class="fixed bottom-7 right-6 z-[600] flex flex-col gap-[.7rem] items-end" aria-label="Quick contact">
    <!-- WhatsApp -->
    <a href="https://wa.me/919910587006" target="_blank" rel="noopener noreferrer"
      class="fab-wa flex items-center gap-[.6rem] px-5 py-[.7rem] bg-[#25D366] text-white text-[.8rem] tracking-[.1em] uppercase font-bold shadow-[0_4px_22px_rgba(0,0,0,.22)] transition-transform duration-200 hover:-translate-x-1"
      aria-label="Chat on WhatsApp">
      <svg class="w-[18px] h-[18px] flex-shrink-0 fill-current" viewBox="0 0 24 24" aria-hidden="true">
        <path
          d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12 0C5.373 0 0 5.373 0 12c0 2.123.553 4.117 1.522 5.845L0 24l6.335-1.502A11.943 11.943 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0z" />
      </svg>
      WhatsApp
    </a>
    <!-- Book Site Visit -->
    <button
      class="flex items-center gap-[.6rem] px-5 py-[.7rem] font-bold text-[.8rem] tracking-[.1em] uppercase text-navy shadow-[0_4px_22px_rgba(0,0,0,.22)] transition-transform duration-200 hover:-translate-x-1"
      style="background:linear-gradient(135deg,#B08840,#E8C97A)" onclick="scrollTo('vip-form')"
      aria-label="Book a site visit">
      <svg class="w-[18px] h-[18px] flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor"
        stroke-width="2.2" aria-hidden="true">
        <rect x="3" y="4" width="18" height="18" rx="2" />
        <line x1="16" y1="2" x2="16" y2="6" />
        <line x1="8" y1="2" x2="8" y2="6" />
        <line x1="3" y1="10" x2="21" y2="10" />
      </svg>
      Book Site Visit
    </button>
  </div>


  <!-- ════════════════════════════════════════════════════════════════════════
     NAV
  ════════════════════════════════════════════════════════════════════════════ -->
  <?php include "include/header.php" ?>


  <!-- ════════════════════════════════════════════════════════════════════════
     HERO
  ════════════════════════════════════════════════════════════════════════════ -->
  <section class="relative min-h-screen flex items-center justify-center overflow-hidden pt-[74px]" id="hero">

    <div class="hero-img" style="background-image: url(assets/images/projects/barog-banner.jpg);"></div>

    <!-- Overlays -->
    <div class="absolute inset-0 pointer-events-none"
      style="background:radial-gradient(ellipse 120% 60% at 50% 100%,rgba(5,18,10,.65) 0%,transparent 70%),radial-gradient(ellipse 80% 40% at 20% 50%,rgba(10,25,15,.3) 0%,transparent 60%),radial-gradient(ellipse 80% 40% at 80% 50%,rgba(13,27,62,.2) 0%,transparent 60%)">
    </div>
    <div class="absolute inset-0"
      style="background:linear-gradient(to bottom,rgba(8,15,32,.68) 0%,rgba(8,15,32,.44) 55%,rgba(8,15,32,.82) 100%)">
    </div>
    <div class="hero-mist absolute inset-0 pointer-events-none"
      style="background:linear-gradient(90deg,transparent,rgba(120,155,180,.1) 45%,rgba(120,155,180,.16) 60%,transparent)">
    </div>

    <!-- Content -->
    <div class="relative z-10 max-w-[1240px] mx-auto px-6 pt-8 pb-20 text-center w-full">
      <div class="max-w-[860px] mx-auto">

        <!-- Soft launch pill -->
        <div class="h1 mb-[1.3rem]">
          <span
            class="inline-flex items-center gap-2 bg-white/10 border border-white/[.22] backdrop-blur-[6px] px-[1.1rem] py-[.48rem] text-[.75rem] tracking-[.14em] uppercase font-semibold text-white/[.92]"
            style="background:linear-gradient(135deg,rgba(176,136,64,.75),rgba(139,105,20,.75));border-color:rgba(232,201,122,.45)">
            <span
              class="w-[22px] h-[22px] rounded-full flex items-center justify-center text-[.75rem] font-bold text-navy flex-shrink-0"
              style="background:rgba(255,255,255,.85)">✦</span>
            Soft Launch Stage — Blocks 2 &amp; 3 Now Open
          </span>
        </div>

        <!-- Price badge -->
        <div class="h1 mb-[1.3rem]">
          <span
            class="inline-flex items-center gap-2 font-serif text-[1.3rem] font-medium tracking-[.04em] text-glt px-[1.4rem] py-[.5rem]"
            style="background:rgba(156, 118, 48, 0.86);border:1px solid rgba(232,201,122,.4)">
            Starting from ₹81 Lakh*
          </span>
        </div>

        <!-- Main headline -->
        <h1 class="h2 font-serif text-white mb-[1.2rem]"
          style="font-size:clamp(4rem,10vw,8rem);font-weight:300;line-height:1.0;letter-spacing:-.01em">
          Breathe<span class="text-glt opacity-80"
            style="font-size:.55em;vertical-align:middle;letter-spacing:-.1em">...</span><br>
          Live<span class="text-glt opacity-80"
            style="font-size:.55em;vertical-align:middle;letter-spacing:-.1em">...</span><br>
          <em class="text-glt">Invest<span class="opacity-90"
              style="font-size:.55em;vertical-align:middle;letter-spacing:-.1em">...</span></em>
        </h1>

        <!-- Sub-headline -->
        <p class="h3 text-white/[.72] max-w-[600px] mx-auto mb-8" style="font-size:1.25rem;line-height:1.8">
          Premium 1-BHK Luxury Residences by Harison Group<br>
          <span class="text-[.92rem] text-white/[.42]">Barog, Himachal Pradesh</span>
        </p>

        <!-- Approval badges -->
        <div class="h4 flex flex-wrap justify-center gap-[.65rem] mb-[2.2rem]">
          <span
            class="inline-flex items-center gap-2 bg-white/10 border border-white/[.22] backdrop-blur-[6px] px-[1.1rem] py-[.48rem] text-[.75rem] tracking-[.14em] uppercase font-semibold text-white/[.92]">
            <span
              class="w-[22px] h-[22px] rounded-full flex items-center justify-center text-[.75rem] font-bold text-navy flex-shrink-0"
              style="background:linear-gradient(135deg,#E8C97A,#B08840)">S</span>SBI Approved
          </span>
          <span
            class="inline-flex items-center gap-2 bg-white/10 border border-white/[.22] backdrop-blur-[6px] px-[1.1rem] py-[.48rem] text-[.75rem] tracking-[.14em] uppercase font-semibold text-white/[.92]">
            <span
              class="w-[22px] h-[22px] rounded-full flex items-center justify-center text-[.75rem] font-bold text-navy flex-shrink-0"
              style="background:linear-gradient(135deg,#E8C97A,#B08840)">H</span>HDFC Approved
          </span>
          <span
            class="inline-flex items-center gap-2 bg-white/10 border border-white/[.22] backdrop-blur-[6px] px-[1.1rem] py-[.48rem] text-[.75rem] tracking-[.14em] uppercase font-semibold text-white/[.92]">
            <span
              class="w-[22px] h-[22px] rounded-full flex items-center justify-center text-[.75rem] font-bold text-navy flex-shrink-0"
              style="background:linear-gradient(135deg,#E8C97A,#B08840)">✓</span>Direct Registry · Non-Himachalis
          </span>
          <span
            class="inline-flex items-center gap-2 bg-white/10 border border-white/[.22] backdrop-blur-[6px] px-[1.1rem] py-[.48rem] text-[.75rem] tracking-[.14em] uppercase font-semibold text-white/[.92]">
            <span
              class="w-[22px] h-[22px] rounded-full flex items-center justify-center text-[.75rem] font-bold text-navy flex-shrink-0"
              style="background:linear-gradient(135deg,#E8C97A,#B08840)">R</span>RERA Registered
          </span>
        </div>

        <!-- CTAs -->
        <div class="h5 flex justify-center gap-4 flex-wrap">
          <button onclick="scrollTo('vip-form')"
            class="inline-block px-[2.8rem] py-[1.05rem] text-navy text-[.82rem] tracking-[.18em] uppercase font-bold border-none cursor-pointer transition-all duration-200 hover:brightness-110"
            style="background:linear-gradient(135deg,#B08840,#E8C97A)">
            Request Official Quotation
          </button>
          <button onclick="scrollTo('inventory')"
            class="inline-block px-[2.6rem] py-[1.05rem] text-white text-[.82rem] tracking-[.18em] uppercase font-medium border-[1.5px] border-white/[.38] hover:bg-white/10 transition-colors duration-200">
            Explore Layouts
          </button>
        </div>

        <!-- RERA micro -->
        <p class="h5 text-[.67rem] tracking-[.2em] uppercase text-white/[.25] mt-[1.8rem]">
          RERA: HPRERASOL 2024119/P · Possession: March 2028 · Exclusively by Rising Nexus Infra
        </p>
      </div>
    </div>

    <!-- Scroll cue -->
    <div class="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-[.35rem]">
      <div class="scroll-line"></div>
      <span class="text-[.67rem] tracking-[.2em] uppercase text-white/[.3]">Scroll</span>
    </div>
  </section>


  <!-- ════════════════════════════════════════════════════════════════════════
     STATS STRIP
  ════════════════════════════════════════════════════════════════════════════ -->
  <div class="bg-navy grid grid-cols-2 md:grid-cols-4">
    <div class="px-8 py-[1.6rem] text-center border-r border-white/[.08]">
      <div class="font-serif text-[2.4rem] font-light text-white/80 leading-none mb-[.3rem]">₹81L</div>
      <div class="text-[.68rem] tracking-[.18em] uppercase text-white/50">Starting Price*</div>
    </div>
    <div class="px-8 py-[1.6rem] text-center border-r border-white/[.08] border-b md:border-b-0">
      <div class="font-serif text-[2.4rem] font-light text-white/80 leading-none mb-[.3rem]">998</div>
      <div class="text-[.68rem] tracking-[.18em] uppercase text-white/50">Max Sq.Ft. — Block 3</div>
    </div>
    <div class="px-8 py-[1.6rem] text-center border-r border-white/[.08]">
      <div class="font-serif text-[2.4rem] font-light text-white/80 leading-none mb-[.3rem]">Mar '28</div>
      <div class="text-[.68rem] tracking-[.18em] uppercase text-white/50">Possession</div>
    </div>
    <div class="px-8 py-[1.6rem] text-center">
      <div class="font-serif text-[2.4rem] font-light text-white/80 leading-none mb-[.3rem]">AQI 32</div>
      <div class="text-[.68rem] tracking-[.18em] uppercase text-white/50">Barog Valley — Excellent</div>
    </div>
  </div>


  <!-- ════════════════════════════════════════════════════════════════════════
     SECTION 2 — AQI SLIDER
  ════════════════════════════════════════════════════════════════════════════ -->
  <section class="bg-rbg py-28 px-16 max-md:py-18 max-md:px-[1.4rem]" id="aqi">
    <div class="max-w-[1240px] mx-auto">

      <div class="fade-up text-center mb-12">
        <div class="flex items-center justify-center gap-[.8rem] mb-[.9rem]">
          <span class="accent-bar block w-14 h-[2px] flex-shrink-0"></span>
          <span class="text-[.75rem] tracking-[.28em] uppercase font-semibold text-rblue">Air Quality Index</span>
          <span class="accent-bar block w-14 h-[2px] flex-shrink-0"></span>
        </div>
        <h2 class="font-serif text-navy" style="font-size:clamp(2.8rem,5vw,4.4rem);font-weight:300;line-height:1.06">
          Your Lungs Deserve <em class="text-gold not-italic">Better.</em>
        </h2>
        <p class="text-rtxt2 max-w-[600px] mx-auto mt-4" style="font-size:1.25rem;line-height:1.8">
          Escape hazardous smog and secure a generational asset just 5.5 hours from the capital. Drag the slider.
        </p>
      </div>

      <!-- AQI Slider -->
      <div class="aqi-wrap fade-up relative overflow-hidden h-[480px] border border-rbdr" id="aqiWrap">
        <!-- Right: Barog -->
        <div class="aqi-right absolute inset-0" style="background: url(assets/images/projects/barog-travel.jpg) no-repeat center / cover ;"></div>
        <!-- Left: Delhi (clipped) -->
        <div class="aqi-left aqi-left-bg absolute inset-0" id="aqiLeft"></div>
        <!-- Haze -->
        <div id="aqiHaze" class="absolute inset-0 pointer-events-none z-[3]"
          style="background:linear-gradient(to right,rgba(80,80,80,.55) 0%,rgba(100,100,100,.35) 60%,transparent 100%);clip-path:inset(0 50% 0 0)">
        </div>

        <!-- AQI Info cards -->
        <div class="absolute z-[5] bottom-8 left-8 p-[.8rem_1.2rem] backdrop-blur-[8px] border border-white/[.15]"
          style="background:rgba(13,27,62,.82)">
          <span class="font-serif text-[2.2rem] font-medium leading-none block mb-[.2rem] text-[#ff5f5f]">380+</span>
          <span class="text-[.98rem] font-semibold text-white block mb-[.1rem]">Delhi NCR</span>
          <span class="text-[.72rem] tracking-[.1em] uppercase text-[rgba(255,95,95,.9)]">AQI: 380+ · Hazardous ⚠</span>
        </div>
        <div
          class="absolute z-[5] bottom-8 right-8 p-[.8rem_1.2rem] backdrop-blur-[8px] border border-white/[.15] text-right"
          style="background:rgba(13,27,62,.82)">
          <span class="font-serif text-[2.2rem] font-medium leading-none block mb-[.2rem] text-[#4ade80]">32</span>
          <span class="text-[.98rem] font-semibold text-white block mb-[.1rem]">Barog Valley</span>
          <span class="text-[.72rem] tracking-[.1em] uppercase text-[rgba(74,222,128,.9)]">AQI: 32 · Excellent ✦</span>
        </div>

        <!-- Divider -->
        <div class="absolute top-0 bottom-0 w-1 z-20 cursor-ew-resize" id="aqiDiv"
          style="background:linear-gradient(to bottom,#E8C97A,#B08840,#E8C97A);box-shadow:0 0 16px rgba(176,136,64,.55)">
          <div
            class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[50px] h-[50px] rounded-full border-[3px] border-white flex items-center justify-center text-[1.15rem] font-bold text-navy shadow-[0_4px_20px_rgba(0,0,0,.3)]"
            style="background:linear-gradient(135deg,#E8C97A,#B08840)">⇔</div>
        </div>

        <!-- Hint -->
        <div id="aqiHint"
          class="absolute top-[1.1rem] left-1/2 -translate-x-1/2 z-[25] pointer-events-none text-[.72rem] tracking-[.14em] uppercase text-white/[.65] px-4 py-[.35rem] transition-opacity duration-[600ms]"
          style="background:rgba(0,0,0,.38)">← Drag to Compare →</div>
      </div>

      <p class="fade-up text-rtxt2 max-w-[660px] mx-auto mt-8 text-center" style="font-size:1.25rem;line-height:1.8">
        <strong>AQI 32 vs 380+</strong> — the difference is not just comfort, it's longevity.
        Pine-scented air at 1,600 m above sea level, starting at just <strong>₹81 Lakh*</strong>.
      </p>
    </div>
  </section>


  <!-- ════════════════════════════════════════════════════════════════════════
     SECTION 3 — PROXIMITY MAP
  ════════════════════════════════════════════════════════════════════════════ -->
  <section class="bg-rsrf py-28 px-16 max-md:py-18 max-md:px-[1.4rem]" id="connectivity">
    <div class="max-w-[1240px] mx-auto">

      <div class="fade-up mb-12">
        <div class="flex items-center gap-[.8rem] mb-[.9rem]">
          <span class="accent-bar block w-14 h-[2px] flex-shrink-0"></span>
          <span class="text-[.75rem] tracking-[.28em] uppercase font-semibold text-rblue">Location &amp;
            Connectivity</span>
        </div>
        <h2 class="font-serif text-navy" style="font-size:clamp(2.8rem,5vw,4.4rem);font-weight:300;line-height:1.06">
          Perfectly Isolated.<br><em class="text-gold not-italic">Perfectly Connected.</em>
        </h2>
        <p class="text-rtxt2 max-w-[560px] mt-[.8rem]" style="font-size:1.25rem;line-height:1.8">
          Click any destination in the sidebar to instantly see its road distance from the project entry point.
        </p>
      </div>

      <!-- Map layout -->
      <div class="fade-up grid grid-cols-1 md:grid-cols-[340px_1fr] border border-rbdr min-h-[600px] md:min-h-[600px]">

        <!-- Sidebar -->
        <div class="map-sidebar bg-navy flex flex-col" id="mapSidebar">
          <div class="px-6 py-[1.4rem] border-b border-white/10">
            <div class="font-serif text-[1.35rem] font-normal text-white mb-[.2rem]">Proximity Explorer</div>
            <div class="text-[.72rem] tracking-[.12em] uppercase text-white/40">Anchor: Project Entry / Site Office
            </div>
          </div>

          <!-- Major Hubs -->
          <div class="px-6 pt-[.7rem] pb-[.4rem]">
            <span
              class="block text-[.62rem] tracking-[.24em] uppercase font-semibold text-glt/[.65] pb-[.5rem] border-b border-white/[.08] mb-[.3rem]">🚗
              Major Hubs</span>
            <button
              class="loc-btn w-full flex items-center gap-[.75rem] px-2 py-[.68rem] bg-transparent border-none border-b border-white/[.06] text-left text-white/[.72] transition-all duration-200 hover:bg-gold/[.12] hover:pl-[.9rem] hover:text-white"
              data-name="Delhi NCR" data-km="290"
              data-route="https://maps.google.com/maps?saddr=Barog+Site+Office+HP&daddr=Delhi+NCR">
              <span class="text-[1.1rem] flex-shrink-0 w-[26px] text-center">🏙️</span>
              <span><span class="text-[.95rem] font-medium block leading-[1.3]">Delhi NCR</span><span
                  class="text-[.72rem] tracking-[.06em] text-glt/80 block mt-[.1rem]">290 km · Road</span></span>
            </button>
            <button
              class="loc-btn w-full flex items-center gap-[.75rem] px-2 py-[.68rem] bg-transparent border-none border-b border-white/[.06] text-left text-white/[.72] transition-all duration-200 hover:bg-gold/[.12] hover:pl-[.9rem] hover:text-white"
              data-name="Chandigarh Airport" data-km="65"
              data-route="https://maps.google.com/maps?saddr=Barog+HP&daddr=Chandigarh+International+Airport">
              <span class="text-[1.1rem] flex-shrink-0 w-[26px] text-center">✈️</span>
              <span><span class="text-[.95rem] font-medium block leading-[1.3]">Chandigarh Airport</span><span
                  class="text-[.72rem] tracking-[.06em] text-glt/80 block mt-[.1rem]">65 km · Road</span></span>
            </button>
            <button
              class="loc-btn w-full flex items-center gap-[.75rem] px-2 py-[.68rem] bg-transparent border-none border-b border-white/[.06] text-left text-white/[.72] transition-all duration-200 hover:bg-gold/[.12] hover:pl-[.9rem] hover:text-white"
              data-name="Shimla" data-km="55" data-route="https://maps.google.com/maps?saddr=Barog+HP&daddr=Shimla+HP">
              <span class="text-[1.1rem] flex-shrink-0 w-[26px] text-center">🏔️</span>
              <span><span class="text-[.95rem] font-medium block leading-[1.3]">Shimla</span><span
                  class="text-[.72rem] tracking-[.06em] text-glt/80 block mt-[.1rem]">55 km · Road</span></span>
            </button>
            <button
              class="loc-btn w-full flex items-center gap-[.75rem] px-2 py-[.68rem] bg-transparent border-none border-b border-white/[.06] text-left text-white/[.72] transition-all duration-200 hover:bg-gold/[.12] hover:pl-[.9rem] hover:text-white"
              data-name="Dehradun" data-km="170"
              data-route="https://maps.google.com/maps?saddr=Barog+HP&daddr=Dehradun+Uttarakhand">
              <span class="text-[1.1rem] flex-shrink-0 w-[26px] text-center">🌿</span>
              <span><span class="text-[.95rem] font-medium block leading-[1.3]">Dehradun</span><span
                  class="text-[.72rem] tracking-[.06em] text-glt/80 block mt-[.1rem]">170 km · Road</span></span>
            </button>
          </div>

          <!-- Education -->
          <div class="px-6 pt-[.7rem] pb-[.4rem]">
            <span
              class="block text-[.62rem] tracking-[.24em] uppercase font-semibold text-glt/[.65] pb-[.5rem] border-b border-white/[.08] mb-[.3rem]">🏫
              Education</span>
            <button
              class="loc-btn w-full flex items-center gap-[.75rem] px-2 py-[.68rem] bg-transparent border-none border-b border-white/[.06] text-left text-white/[.72] transition-all duration-200 hover:bg-gold/[.12] hover:pl-[.9rem] hover:text-white"
              data-name="Army Public School, Dagshai" data-km="3.5"
              data-route="https://maps.google.com/maps?saddr=Barog+HP&daddr=Army+Public+School+Dagshai+HP">
              <span class="text-[1.1rem] flex-shrink-0 w-[26px] text-center">🎓</span>
              <span><span class="text-[.95rem] font-medium block leading-[1.3]">Army Public School, Dagshai</span><span
                  class="text-[.72rem] tracking-[.06em] text-glt/80 block mt-[.1rem]">3.5 km</span></span>
            </button>
          </div>

          <!-- Healthcare -->
          <div class="px-6 pt-[.7rem] pb-[.4rem]">
            <span
              class="block text-[.62rem] tracking-[.24em] uppercase font-semibold text-glt/[.65] pb-[.5rem] border-b border-white/[.08] mb-[.3rem]">🏥
              Healthcare</span>
            <button
              class="loc-btn w-full flex items-center gap-[.75rem] px-2 py-[.68rem] bg-transparent border-none border-b border-white/[.06] text-left text-white/[.72] transition-all duration-200 hover:bg-gold/[.12] hover:pl-[.9rem] hover:text-white"
              data-name="BANSAL ORTHOPAEDIC AND GENERAL HOSPITAL, DEV BUILDING, Himachal Pradesh" data-km="9"
              data-route="https://maps.google.com/maps?saddr=Barog+HP&daddr=Bansal+Orthopaedic+Solan+HP">
              <span class="text-[1.1rem] flex-shrink-0 w-[26px] text-center">🦴</span>
              <span><span class="text-[.95rem] font-medium block leading-[1.3]">Bansal Orthopaedic Centre</span><span
                  class="text-[.72rem] tracking-[.06em] text-glt/80 block mt-[.1rem]">9 km</span></span>
            </button>
            <button
              class="loc-btn w-full flex items-center gap-[.75rem] px-2 py-[.68rem] bg-transparent border-none border-b border-white/[.06] text-left text-white/[.72] transition-all duration-200 hover:bg-gold/[.12] hover:pl-[.9rem] hover:text-white"
              data-name="Maharishi Markandeshwar Hospital" data-km="14"
              data-route="https://maps.google.com/maps?saddr=Barog+HP&daddr=Maharishi+Markandeshwar+Hospital+HP">
              <span class="text-[1.1rem] flex-shrink-0 w-[26px] text-center">🏥</span>
              <span><span class="text-[.95rem] font-medium block leading-[1.3]">Maharishi Markandeshwar
                  Hosp.</span><span class="text-[.72rem] tracking-[.06em] text-glt/80 block mt-[.1rem]">14
                  km</span></span>
            </button>
          </div>

          <!-- Leisure -->
          <div class="px-6 pt-[.7rem] pb-[.4rem]">
            <span
              class="block text-[.62rem] tracking-[.24em] uppercase font-semibold text-glt/[.65] pb-[.5rem] border-b border-white/[.08] mb-[.3rem]">🛍️
              Leisure &amp; Essentials</span>
            <button
              class="loc-btn w-full flex items-center gap-[.75rem] px-2 py-[.68rem] bg-transparent border-none border-b border-white/[.06] text-left text-white/[.72] transition-all duration-200 hover:bg-gold/[.12] hover:pl-[.9rem] hover:text-white"
              data-name="Vivanta Mall, Solan" data-km="14"
              data-route="https://maps.google.com/maps?saddr=Barog+HP&daddr=Vivanta+Mall+Solan+HP">
              <span class="text-[1.1rem] flex-shrink-0 w-[26px] text-center">🛒</span>
              <span><span class="text-[.95rem] font-medium block leading-[1.3]">Vivanta Mall, Solan</span><span
                  class="text-[.72rem] tracking-[.06em] text-glt/80 block mt-[.1rem]">14 km</span></span>
            </button>
            <button
              class="loc-btn w-full flex items-center gap-[.75rem] px-2 py-[.68rem] bg-transparent border-none border-b border-white/[.06] text-left text-white/[.72] transition-all duration-200 hover:bg-gold/[.12] hover:pl-[.9rem] hover:text-white"
              data-name="Dharampur Haveli Restaurant" data-km="6"
              data-route="https://maps.google.com/maps?saddr=Barog+HP&daddr=Dharampur+Haveli+HP">
              <span class="text-[1.1rem] flex-shrink-0 w-[26px] text-center">🍽️</span>
              <span><span class="text-[.95rem] font-medium block leading-[1.3]">Dharampur Haveli Restaurant</span><span
                  class="text-[.72rem] tracking-[.06em] text-glt/80 block mt-[.1rem]">6 km</span></span>
            </button>
            <button
              class="loc-btn w-full flex items-center gap-[.75rem] px-2 py-[.68rem] bg-transparent border-none border-b border-white/[.06] text-left text-white/[.72] transition-all duration-200 hover:bg-gold/[.12] hover:pl-[.9rem] hover:text-white"
              data-name="McDonald's, Jabli" data-km="11"
              data-route="https://maps.google.com/maps?saddr=Barog+HP&daddr=McDonalds+Jabli+HP">
              <span class="text-[1.1rem] flex-shrink-0 w-[26px] text-center">🍔</span>
              <span><span class="text-[.95rem] font-medium block leading-[1.3]">McDonald's, Jabli</span><span
                  class="text-[.72rem] tracking-[.06em] text-glt/80 block mt-[.1rem]">11 km</span></span>
            </button>
            <button
              class="loc-btn w-full flex items-center gap-[.75rem] px-2 py-[.68rem] bg-transparent border-none border-b border-white/[.06] text-left text-white/[.72] transition-all duration-200 hover:bg-gold/[.12] hover:pl-[.9rem] hover:text-white"
              data-name="Lord of the Drinks, Jabli" data-km="11"
              data-route="https://maps.google.com/maps?saddr=Barog+HP&daddr=Lord+of+the+Drinks+Jabli+HP">
              <span class="text-[1.1rem] flex-shrink-0 w-[26px] text-center">🍸</span>
              <span><span class="text-[.95rem] font-medium block leading-[1.3]">Lord of the Drinks, Jabli</span><span
                  class="text-[.72rem] tracking-[.06em] text-glt/80 block mt-[.1rem]">11 km</span></span>
            </button>
          </div>
        </div>

        <!-- Map right -->
        <div class="relative flex flex-col" id="mapRight">
          <!-- Distance toast -->
          <div
            class="dist-toast absolute top-4 left-1/2 z-10 bg-navy border border-gold p-[1rem_1.4rem] min-w-[280px] max-w-[360px] shadow-[0_8px_32px_rgba(13,27,62,.22)]"
            id="distToast">
            <button
              class="absolute top-[.6rem] right-[.7rem] bg-none border-none text-white/40 text-[1.1rem] cursor-pointer hover:text-white transition-colors p-[.1rem_.3rem]"
              id="toastClose" aria-label="Close">✕</button>
            <span class="block text-[.62rem] tracking-[.18em] uppercase text-glt mb-[.3rem]">Distance from Project Entry
              / Site Office</span>
            <div class="font-serif text-[1.3rem] font-normal text-white mb-[.2rem]" id="toastName">—</div>
            <div class="text-[1rem] text-white/70 mb-[.8rem]">Road Distance: <strong
                class="text-glt font-serif text-[1.3rem]" id="toastKm">—</strong> km</div>
            <a class="inline-flex items-center gap-[.45rem] text-[.72rem] tracking-[.15em] uppercase font-bold px-5 py-[.55rem] text-navy transition-all duration-200 hover:brightness-110"
              style="background:linear-gradient(135deg,#B08840,#E8C97A)" id="toastRoute" href="#" target="_blank"
              rel="noopener noreferrer">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                <path
                  d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
              </svg>
              View Route on Google Maps
            </a>
          </div>
          <iframe id="mapFrame" src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d1775389.8631936267!2d75.46326492292701!3d29.645568712754994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e6!4m5!1s0x390f869effffffff%3A0x93e08dc71edf4261!2sThe%20Pinewood%20Barog%2C%20Barog%2C%20Himachal%20Pradesh%20173229!3m2!1d30.8908939!2d77.074407!4m5!1s0x390ce19466e19ae1%3A0x45ceeb565fd5de6c!2sNational%20Capital%20Region!3m2!1d28.4020007!2d76.8259652!5e0!3m2!1sen!2sin!4v1777716587565!5m2!1sen!2sin"
            class="flex-1 border-0 block min-h-[480px] md:min-h-0"
            allowfullscreen=""
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"></iframe>


          <div class="px-5 py-[.75rem] bg-navy border-t border-white/10 flex items-center gap-[.6rem]">
            <span
              class="w-[9px] h-[9px] rounded-full bg-[#4ade80] flex-shrink-0 shadow-[0_0_6px_rgba(74,222,128,.6)]"></span>
            <span class="text-[.8rem] tracking-[.1em] uppercase font-semibold text-white/[.75]">Anchor: Project Entry /
              Site Office · Barog, H.P.</span>
          </div>
        </div>
      </div>
    </div>
    <script>
      document.querySelectorAll('.loc-btn').forEach(btn => {
        btn.addEventListener('click', function() {
          const name = this.dataset.name;
          const km = this.dataset.km;
          const route = this.dataset.route;

          // Toast update
          document.getElementById('toastName').textContent = name;
          document.getElementById('toastKm').textContent = km;
          document.getElementById('toastRoute').href = route;
          document.getElementById('distToast').style.display = 'block';

          const origin = 'The Pinewood Barog, Barog, Himachal Pradesh 173229';
          const dest = encodeURIComponent(name + ', India');
          document.getElementById('mapFrame').src = `https://maps.google.com/maps?saddr=${origin}&daddr=${dest}&output=embed`;
          // document.getElementById('mapFrame').src = `${route}&output=embed`;
        });
      });

      document.getElementById('toastClose').addEventListener('click', () => {
        document.getElementById('distToast').style.display = 'none';
      });
    </script>
  </section>


  <!-- ════════════════════════════════════════════════════════════════════════
     SECTION 4 — FLOOR PLAN VIEWER
  ════════════════════════════════════════════════════════════════════════════ -->
  <section class="bg-rs2 py-28 px-16 max-md:py-18 max-md:px-[1.4rem]" id="inventory">
    <div class="max-w-[1240px] mx-auto">

      <div class="fade-up text-center mb-12">
        <div class="flex items-center justify-center gap-[.8rem] mb-[.9rem]">
          <span class="accent-bar block w-14 h-[2px] flex-shrink-0"></span>
          <span class="text-[.75rem] tracking-[.28em] uppercase font-semibold text-rblue">Inventory &amp; Floor
            Plans</span>
          <span class="accent-bar block w-14 h-[2px] flex-shrink-0"></span>
        </div>
        <h2 class="font-serif text-navy" style="font-size:clamp(2.8rem,5vw,4.4rem);font-weight:300;line-height:1.06">
          Choose Your <em class="text-gold not-italic">Residence</em>
        </h2>
        <p class="text-rmuted max-w-[520px] mx-auto mt-[.8rem]" style="font-size:1.25rem;line-height:1.8">
          Blocks 2 &amp; 3 open for immediate booking. Block 1 launches after Block 2 sells out.
        </p>
      </div>

      <!-- TABS -->
      <div class="fade-up grid grid-cols-3 border border-rbdr bg-rsrf mb-10">
        <!-- Block 3 -->
        <div id="tab-b3" onclick="switchTab('b3')" role="tab" aria-selected="true" tabindex="0"
          class="p-tab active p-6 text-left cursor-pointer border-r border-rbdr border-t-[3px] border-t-gold bg-navy transition-all duration-200">
          <div class="text-[.65rem] tracking-[.22em] uppercase mb-[.3rem] text-white/50">Block 3</div>
          <div class="font-serif text-[1.45rem] font-normal leading-[1.2] mb-[.3rem] text-white">998 Sq.Ft.</div>
          <div class="text-[.82rem] font-semibold text-glt">Super Premium · Open</div>
        </div>
        <!-- Block 2 -->
        <div id="tab-b2" onclick="switchTab('b2')" role="tab" aria-selected="false" tabindex="0"
          class="p-tab p-6 text-left cursor-pointer border-r border-rbdr border-t-[3px] border-t-transparent bg-rsrf hover:bg-rs2 transition-all duration-200">
          <div class="text-[.65rem] tracking-[.22em] uppercase mb-[.3rem] text-rmuted">Block 2</div>
          <div class="font-serif text-[1.45rem] font-normal leading-[1.2] mb-[.3rem] text-navy">772 Sq.Ft.</div>
          <div class="text-[.82rem] font-semibold text-gold">Premium · Open</div>
        </div>
        <!-- Block 1 — Locked -->
        <div id="tab-b1" onclick="switchTab('b1')" role="tab" aria-selected="false" tabindex="0"
          aria-label="Block 1 — Coming Soon"
          class="p-tab locked relative p-6 text-left cursor-not-allowed opacity-60 border-t-[3px] border-t-transparent bg-rsrf">
          <span
            class="absolute top-[.6rem] right-[.7rem] text-[.58rem] tracking-[.16em] uppercase font-bold px-[.65rem] py-[.24rem] bg-rs2 text-rmuted border border-rbds">COMING
            SOON</span>
          <div class="text-[.65rem] tracking-[.22em] uppercase mb-[.3rem] text-rmuted">Block 1</div>
          <div class="font-serif text-[1.45rem] font-normal leading-[1.2] mb-[.3rem] text-rmuted">752 Sq.Ft.</div>
          <div class="text-[.82rem] font-semibold text-rmuted">Standard · Reserved</div>
        </div>
      </div>

      <!-- PANEL: Block 3 -->
      <div class="plan-panel active grid-cols-1 md:grid-cols-[1.1fr_1fr] gap-10 items-start" id="panel-b3">
        <div class="relative border border-rbdr bg-rsrf overflow-hidden fade-up">
          <img src="https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=700&q=70"
            alt="Block 3 — 998 Sq.Ft. Super Premium floor plan placeholder"
            class="w-full block min-h-[340px] object-cover" />
          <div class="px-[1.1rem] py-[.7rem] bg-rs2 border-t border-rbdr text-[.78rem] text-rmuted">
            ⚠ Placeholder — replace <code>src</code> with your official Block 3 layout screenshot.
          </div>
        </div>
        <div class="fade-up">
          <div class="mb-6">
            <span class="text-[.67rem] tracking-[.2em] uppercase text-rmuted">Block 3</span>
            <h3 class="font-serif text-navy mt-[.3rem] mb-0"
              style="font-size:clamp(2.1rem,3.8vw,3.2rem);font-weight:300;line-height:1.1">Super Premium · 998 Sq.Ft.
            </h3>
            <span class="accent-bar block w-14 h-[2px] mt-[.6rem]"></span>
          </div>
          <div class="grid grid-cols-2 gap-[.8rem] mb-[1.8rem]">
            <div class="bg-rsrf border border-rbdr p-[1rem_1.2rem]">
              <div class="text-[.58rem] tracking-[.2em] uppercase text-rmuted mb-[.3rem]">Unit Size</div>
              <div class="text-[1rem] font-semibold text-navy">998 Sq.Ft.</div>
            </div>
            <div class="bg-rsrf border border-rbdr p-[1rem_1.2rem]">
              <div class="text-[.58rem] tracking-[.2em] uppercase text-rmuted mb-[.3rem]">Configuration</div>
              <div class="text-[1rem] font-semibold text-navy">1 BHK Luxury</div>
            </div>
            <div class="bg-rsrf border border-rbdr p-[1rem_1.2rem]">
              <div class="text-[.58rem] tracking-[.2em] uppercase text-rmuted mb-[.3rem]">Grade</div>
              <div class="font-serif text-[1.3rem] text-gold">Super Premium</div>
            </div>
            <div class="bg-rsrf border border-rbdr p-[1rem_1.2rem]">
              <div class="text-[.58rem] tracking-[.2em] uppercase text-rmuted mb-[.3rem]">Possession</div>
              <div class="text-[1rem] font-semibold text-navy">March 2028</div>
            </div>
            <div class="bg-rsrf border border-rbdr p-[1rem_1.2rem]">
              <div class="text-[.58rem] tracking-[.2em] uppercase text-rmuted mb-[.3rem]">Approval</div>
              <div class="text-[1rem] font-semibold text-rgreen">SBI &amp; HDFC</div>
            </div>
            <div class="bg-rsrf border border-rbdr p-[1rem_1.2rem]">
              <div class="text-[.58rem] tracking-[.2em] uppercase text-rmuted mb-[.3rem]">Status</div>
              <div class="text-[1rem] font-semibold text-rgreen">Open for Booking</div>
            </div>
          </div>
          <ul class="list-none mb-8 space-y-0">
            <li class="flex items-start gap-[.65rem] py-[.46rem] border-b border-rbdr/70 text-[.97rem] text-rtxt2"><span
                class="w-[7px] h-[7px] rounded-full bg-gold flex-shrink-0 mt-[.48rem]"></span>Mountain-view private
              balcony</li>
            <li class="flex items-start gap-[.65rem] py-[.46rem] border-b border-rbdr/70 text-[.97rem] text-rtxt2"><span
                class="w-[7px] h-[7px] rounded-full bg-gold flex-shrink-0 mt-[.48rem]"></span>Premium modular kitchen
            </li>
            <li class="flex items-start gap-[.65rem] py-[.46rem] border-b border-rbdr/70 text-[.97rem] text-rtxt2"><span
                class="w-[7px] h-[7px] rounded-full bg-gold flex-shrink-0 mt-[.48rem]"></span>Master bedroom with
              ensuite bath</li>
            <li class="flex items-start gap-[.65rem] py-[.46rem] border-b border-rbdr/70 text-[.97rem] text-rtxt2"><span
                class="w-[7px] h-[7px] rounded-full bg-gold flex-shrink-0 mt-[.48rem]"></span>High-grade vitrified tile
              flooring</li>
            <li class="flex items-start gap-[.65rem] py-[.46rem] border-b border-rbdr/70 text-[.97rem] text-rtxt2"><span
                class="w-[7px] h-[7px] rounded-full bg-gold flex-shrink-0 mt-[.48rem]"></span>Covered dedicated car
              parking</li>
            <li class="flex items-start gap-[.65rem] py-[.46rem] border-b border-rbdr/70 text-[.97rem] text-rtxt2"><span
                class="w-[7px] h-[7px] rounded-full bg-gold flex-shrink-0 mt-[.48rem]"></span>High-speed passenger
              elevator</li>
            <li class="flex items-start gap-[.65rem] py-[.46rem] border-b border-rbdr/70 text-[.97rem] text-rtxt2"><span
                class="w-[7px] h-[7px] rounded-full bg-gold flex-shrink-0 mt-[.48rem]"></span>24×7 CCTV security</li>
            <li class="flex items-start gap-[.65rem] py-[.46rem] border-b border-rbdr/70 text-[.97rem] text-rtxt2"><span
                class="w-[7px] h-[7px] rounded-full bg-gold flex-shrink-0 mt-[.48rem]"></span>100% power backup</li>
            <li class="flex items-start gap-[.65rem] py-[.46rem] text-[.97rem] text-rtxt2"><span
                class="w-[7px] h-[7px] rounded-full bg-gold flex-shrink-0 mt-[.48rem]"></span>Landscaped common gardens
            </li>
          </ul>
          <div class="flex gap-[.8rem] flex-wrap">
            <button onclick="scrollTo('vip-form')"
              class="inline-block px-[2.4rem] py-4 bg-navy text-white text-[.78rem] tracking-[.17em] uppercase font-semibold border-none cursor-pointer hover:bg-rblue transition-colors duration-200">Book
              Block 3</button>
            <button onclick="alert('Blueprint will be emailed to you. Submit the enquiry form below.')"
              class="inline-block px-8 py-4 border-[1.5px] border-rbds text-rtxt2 bg-rsrf text-[.78rem] tracking-[.17em] uppercase font-medium cursor-pointer hover:bg-rs2 hover:border-navy transition-colors duration-200">Download
              Blueprint</button>
          </div>
          <p class="text-[.78rem] text-rmuted mt-[.8rem] leading-[1.6]">* Possession March 2028. Subject to
            availability. T&amp;C apply.</p>
        </div>
      </div>

      <!-- PANEL: Block 2 -->
      <div class="plan-panel grid-cols-1 md:grid-cols-[1.1fr_1fr] gap-10 items-start" id="panel-b2">
        <div class="relative border border-rbdr bg-rsrf overflow-hidden fade-up">
          <img src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=700&q=70"
            alt="Block 2 — 772 Sq.Ft. Premium floor plan placeholder" class="w-full block min-h-[340px] object-cover" />
          <div class="px-[1.1rem] py-[.7rem] bg-rs2 border-t border-rbdr text-[.78rem] text-rmuted">
            ⚠ Placeholder — replace <code>src</code> with your official Block 2 layout screenshot.
          </div>
        </div>
        <div class="fade-up">
          <div class="mb-6">
            <span class="text-[.67rem] tracking-[.2em] uppercase text-rmuted">Block 2</span>
            <h3 class="font-serif text-navy mt-[.3rem] mb-0"
              style="font-size:clamp(2.1rem,3.8vw,3.2rem);font-weight:300;line-height:1.1">Premium · 772 Sq.Ft.</h3>
            <span class="accent-bar block w-14 h-[2px] mt-[.6rem]"></span>
          </div>
          <div class="grid grid-cols-2 gap-[.8rem] mb-[1.8rem]">
            <div class="bg-rsrf border border-rbdr p-[1rem_1.2rem]">
              <div class="text-[.58rem] tracking-[.2em] uppercase text-rmuted mb-[.3rem]">Unit Size</div>
              <div class="text-[1rem] font-semibold text-navy">772 Sq.Ft.</div>
            </div>
            <div class="bg-rsrf border border-rbdr p-[1rem_1.2rem]">
              <div class="text-[.58rem] tracking-[.2em] uppercase text-rmuted mb-[.3rem]">Configuration</div>
              <div class="text-[1rem] font-semibold text-navy">1 BHK Luxury</div>
            </div>
            <div class="bg-rsrf border border-rbdr p-[1rem_1.2rem]">
              <div class="text-[.58rem] tracking-[.2em] uppercase text-rmuted mb-[.3rem]">Grade</div>
              <div class="font-serif text-[1.3rem] text-gold">Premium</div>
            </div>
            <div class="bg-rsrf border border-rbdr p-[1rem_1.2rem]">
              <div class="text-[.58rem] tracking-[.2em] uppercase text-rmuted mb-[.3rem]">Possession</div>
              <div class="text-[1rem] font-semibold text-navy">March 2028</div>
            </div>
            <div class="bg-rsrf border border-rbdr p-[1rem_1.2rem]">
              <div class="text-[.58rem] tracking-[.2em] uppercase text-rmuted mb-[.3rem]">Approval</div>
              <div class="text-[1rem] font-semibold text-rgreen">SBI &amp; HDFC</div>
            </div>
            <div class="bg-rsrf border border-rbdr p-[1rem_1.2rem]">
              <div class="text-[.58rem] tracking-[.2em] uppercase text-rmuted mb-[.3rem]">Status</div>
              <div class="text-[1rem] font-semibold text-rgreen">Open for Booking</div>
            </div>
          </div>
          <ul class="list-none mb-8 space-y-0">
            <li class="flex items-start gap-[.65rem] py-[.46rem] border-b border-rbdr/70 text-[.97rem] text-rtxt2"><span
                class="w-[7px] h-[7px] rounded-full bg-gold flex-shrink-0 mt-[.48rem]"></span>Valley-facing private
              balcony</li>
            <li class="flex items-start gap-[.65rem] py-[.46rem] border-b border-rbdr/70 text-[.97rem] text-rtxt2"><span
                class="w-[7px] h-[7px] rounded-full bg-gold flex-shrink-0 mt-[.48rem]"></span>Modular kitchen with
              premium fittings</li>
            <li class="flex items-start gap-[.65rem] py-[.46rem] border-b border-rbdr/70 text-[.97rem] text-rtxt2"><span
                class="w-[7px] h-[7px] rounded-full bg-gold flex-shrink-0 mt-[.48rem]"></span>Spacious bedroom with
              attached bath</li>
            <li class="flex items-start gap-[.65rem] py-[.46rem] border-b border-rbdr/70 text-[.97rem] text-rtxt2"><span
                class="w-[7px] h-[7px] rounded-full bg-gold flex-shrink-0 mt-[.48rem]"></span>Vitrified tile flooring
              throughout</li>
            <li class="flex items-start gap-[.65rem] py-[.46rem] border-b border-rbdr/70 text-[.97rem] text-rtxt2"><span
                class="w-[7px] h-[7px] rounded-full bg-gold flex-shrink-0 mt-[.48rem]"></span>Covered car parking space
            </li>
            <li class="flex items-start gap-[.65rem] py-[.46rem] border-b border-rbdr/70 text-[.97rem] text-rtxt2"><span
                class="w-[7px] h-[7px] rounded-full bg-gold flex-shrink-0 mt-[.48rem]"></span>24×7 security &amp; power
              backup</li>
            <li class="flex items-start gap-[.65rem] py-[.46rem] border-b border-rbdr/70 text-[.97rem] text-rtxt2"><span
                class="w-[7px] h-[7px] rounded-full bg-gold flex-shrink-0 mt-[.48rem]"></span>Communal landscaped garden
            </li>
            <li class="flex items-start gap-[.65rem] py-[.46rem] text-[.97rem] text-rtxt2"><span
                class="w-[7px] h-[7px] rounded-full bg-gold flex-shrink-0 mt-[.48rem]"></span>High-speed elevator access
            </li>
          </ul>
          <div class="flex gap-[.8rem] flex-wrap">
            <button onclick="scrollTo('vip-form')"
              class="inline-block px-[2.4rem] py-4 bg-navy text-white text-[.78rem] tracking-[.17em] uppercase font-semibold border-none cursor-pointer hover:bg-rblue transition-colors duration-200">Book
              Block 2</button>
            <button onclick="alert('Blueprint will be emailed to you. Submit the enquiry form below.')"
              class="inline-block px-8 py-4 border-[1.5px] border-rbds text-rtxt2 bg-rsrf text-[.78rem] tracking-[.17em] uppercase font-medium cursor-pointer hover:bg-rs2 hover:border-navy transition-colors duration-200">Download
              Blueprint</button>
          </div>
          <p class="text-[.78rem] text-rmuted mt-[.8rem] leading-[1.6]">* Possession March 2028. Subject to
            availability. T&amp;C apply.</p>
        </div>
      </div>

      <!-- PANEL: Block 1 — Locked -->
      <div class="plan-panel grid-cols-1 md:grid-cols-[1.1fr_1fr] gap-10 items-start" id="panel-b1">
        <div class="relative border border-rbdr bg-rsrf overflow-hidden fade-up">
          <img src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=700&q=30"
            alt="Block 1 — layout hidden until launch" class="w-full block object-cover min-h-[360px]"
            style="filter:blur(8px) grayscale(50%) brightness(.55)" />
          <div class="absolute inset-0 z-10 flex flex-col items-center justify-center gap-4 text-center px-8"
            style="background:rgba(13,27,62,.96)">
            <div class="plan-locked-word">COMING SOON</div>
            <div class="text-[1rem] text-white/[.65] tracking-[.08em] uppercase font-medium">Launches after Block 2
              sells out</div>
            <p class="text-[.9rem] text-white/[.45] max-w-[240px] leading-[1.65]">Register your interest below and our
              team will notify you the moment Block 1 opens.</p>
            <button onclick="scrollTo('vip-form')"
              class="inline-block px-[2.4rem] py-4 bg-navy text-white text-[.78rem] tracking-[.17em] uppercase font-semibold border-none cursor-pointer hover:bg-rblue transition-colors duration-200">Register
              Interest</button>
          </div>
        </div>
        <div class="opacity-35 pointer-events-none select-none fade-up">
          <div class="mb-6">
            <span class="text-[.67rem] tracking-[.2em] uppercase text-rmuted">Block 1</span>
            <h3 class="font-serif text-rmuted mt-[.3rem]"
              style="font-size:clamp(2.1rem,3.8vw,3.2rem);font-weight:300;line-height:1.1">Standard · 752 Sq.Ft.</h3>
          </div>
          <div class="grid grid-cols-2 gap-[.8rem]">
            <div class="bg-rsrf border border-rbdr p-[1rem_1.2rem]">
              <div class="text-[.58rem] tracking-[.2em] uppercase text-rmuted mb-[.3rem]">Unit Size</div>
              <div class="text-[1rem] font-semibold text-navy">752 Sq.Ft.</div>
            </div>
            <div class="bg-rsrf border border-rbdr p-[1rem_1.2rem]">
              <div class="text-[.58rem] tracking-[.2em] uppercase text-rmuted mb-[.3rem]">Status</div>
              <div class="text-[1rem] font-semibold text-navy">Details Locked</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>


  <!-- ════════════════════════════════════════════════════════════════════════
     SECTION 5 — PARTNER BANNER
  ════════════════════════════════════════════════════════════════════════════ -->
  <div class="partner-bg relative overflow-hidden text-center px-16 py-[4.5rem] max-md:px-[1.4rem]"
    style="background:linear-gradient(135deg,#8B6914 0%,#B08840 28%,#E8C97A 50%,#B08840 72%,#8B6914 100%)"
    id="partnership">
    <div class="relative z-[2] max-w-[820px] mx-auto fade-up">

      <!-- RNI Logo -->
      <div class="inline-flex flex-col items-center mb-[1.8rem]">
        <span class="font-serif text-[1.8rem] font-bold tracking-[.08em] text-navy uppercase">Rising Nexus Infra</span>
        <span class="text-[.52rem] tracking-[.22em] text-navy/50 uppercase mt-[2px]">Infrastructure · Investment ·
          Innovation</span>
      </div>

      <div class="gold-bar block w-[100px] h-[2px] mx-auto mb-[1.8rem]"></div>

      <h2 class="font-serif text-navy mb-4" style="font-size:clamp(2.8rem,5vw,4.4rem);font-weight:300;line-height:1.06">
        Rising Nexus Infra:<br>The Exclusive Strategic Partner.
      </h2>
      <p class="text-navy/[.75] max-w-[660px] mx-auto mb-[1.4rem]" style="font-size:1.1rem;line-height:1.85">
        RNI is the <strong>sole authorised marketing, sales, and collection partner</strong>
        for Phase 1 of Harison Group, Barog — every inquiry and transaction is handled
        exclusively through our team.
      </p>

      <p class="text-navy/[.62] mb-[1.3rem]" style="font-size:1.1rem;line-height:1.85">
        Official developer details:
        <a href="https://barogvalley.com/" target="_blank" rel="noopener noreferrer"
          class="text-navy font-bold underline">barogvalley.com ↗</a>
      </p>

      <div class="flex flex-wrap justify-center gap-[.65rem] my-[1.4rem]">
        <span
          class="inline-flex items-center gap-[.35rem] px-4 py-[.44rem] bg-navy/10 border border-navy/20 text-[.72rem] tracking-[.12em] uppercase font-semibold text-navy">✓
          RERA Registered</span>
        <span
          class="inline-flex items-center gap-[.35rem] px-4 py-[.44rem] bg-navy/10 border border-navy/20 text-[.72rem] tracking-[.12em] uppercase font-semibold text-navy">✓
          SBI Approved</span>
        <span
          class="inline-flex items-center gap-[.35rem] px-4 py-[.44rem] bg-navy/10 border border-navy/20 text-[.72rem] tracking-[.12em] uppercase font-semibold text-navy">✓
          HDFC Approved</span>
        <span
          class="inline-flex items-center gap-[.35rem] px-4 py-[.44rem] bg-navy/10 border border-navy/20 text-[.72rem] tracking-[.12em] uppercase font-semibold text-navy">✓
          Direct Registry — Non-Himachalis</span>
        <span
          class="inline-flex items-center gap-[.35rem] px-4 py-[.44rem] bg-navy/10 border border-navy/20 text-[.72rem] tracking-[.12em] uppercase font-semibold text-navy">✓
          Soft Launch Phase</span>
      </div>

      <div class="text-[.78rem] text-navy/50 leading-[1.75] mt-[1.3rem]">
        Project RERA Registration No: <strong>HPRERASOL 2024119/P</strong> | Valid upto: 09/12/2029<br />
        Marketed exclusively by Rising Nexus Infra | Corporate Office: Noida, U.P.<br />
        Starting from ₹81 Lakh*. All prices indicative, subject to revision. T&amp;C Apply.
      </div>
    </div>
  </div>


  <!-- ════════════════════════════════════════════════════════════════════════
     SECTION 6 — VIP CONCIERGE FOOTER
  ════════════════════════════════════════════════════════════════════════════ -->
  <section class="footer-grid-bg relative bg-navy overflow-hidden py-28 px-16 max-md:py-18 max-md:px-[1.4rem]"
    id="vip-form">
    <div class="max-w-[1240px] mx-auto relative z-[2]">
      <div class="grid grid-cols-1 md:grid-cols-2 gap-20 md:gap-20 items-start">

        <!-- Info col -->
        <div>
          <div class="flex items-center gap-[.75rem] mb-[1.1rem]">
            <span class="w-[26px] h-[2px] flex-shrink-0"
              style="background:linear-gradient(90deg,#8B6914,#E8C97A)"></span>
            <span class="text-[.75rem] tracking-[.28em] uppercase font-semibold text-glt">VIP Concierge</span>
          </div>
          <h2 class="font-serif text-white mb-[.8rem]"
            style="font-size:clamp(2.8rem,5vw,4.4rem);font-weight:300;line-height:1.06">
            Reserve Your<br><em class="text-glt not-italic">Mountain Legacy.</em>
          </h2>
          <p class="text-white/[.52] mb-0" style="font-size:1.25rem;line-height:1.8">
            Our team will contact you within 24 hours with an official
            quotation and available inventory — tailored to your investment goals.
          </p>

          <!-- Action buttons -->
          <div class="grid grid-cols-2 gap-[.7rem] mt-[1.4rem]">
            <a href="https://wa.me/919910587006" target="_blank" rel="noopener noreferrer"
              class="flex items-center justify-center gap-[.55rem] px-4 py-4 bg-[#25D366] text-white text-[.82rem] tracking-[.13em] uppercase font-bold no-underline hover:brightness-110 transition-all duration-200">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path
                  d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12 0C5.373 0 0 5.373 0 12c0 2.123.553 4.117 1.522 5.845L0 24l6.335-1.502A11.943 11.943 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0z" />
              </svg>
              Chat on WhatsApp
            </a>
            <a href="tel:+919910587006"
              class="flex items-center justify-center gap-[.55rem] px-4 py-4 text-navy text-[.82rem] tracking-[.13em] uppercase font-bold no-underline hover:brightness-110 transition-all duration-200"
              style="background:linear-gradient(135deg,#B08840,#E8C97A)">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
                <path
                  d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.8 19.79 19.79 0 01.07 1.2 2 2 0 012.06 0h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.09 7.91A16 16 0 0016.08 17.9l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z" />
              </svg>
              Call for Allocation
            </a>
          </div>

          <ul class="list-none mt-[1.4rem]">
            <li class="flex items-start gap-[.8rem] py-[.8rem] border-b border-white/[.07] text-[.97rem]">
              <span class="text-[1.1rem] flex-shrink-0 mt-[.08rem]">📞</span>
              <div><span class="block text-[.6rem] tracking-[.2em] uppercase text-glt mb-[.15rem]">Strategic
                  Partner</span><a href="tel:+919910587006" class="text-white/[.72]">+91 99105 87006</a></div>
            </li>
            <li class="flex items-start gap-[.8rem] py-[.8rem] border-b border-white/[.07] text-[.97rem]">
              <span class="text-[1.1rem] flex-shrink-0 mt-[.08rem]">✉️</span>
              <div><span class="block text-[.6rem] tracking-[.2em] uppercase text-glt mb-[.15rem]">Sales
                  Enquiries</span><a href="mailto:sales@risingnexusinfra.com"
                  class="text-white/[.72]">sales@risingnexusinfra.com</a></div>
            </li>
            <li class="flex items-start gap-[.8rem] py-[.8rem] border-b border-white/[.07] text-[.97rem]">
              <span class="text-[1.1rem] flex-shrink-0 mt-[.08rem]">🌐</span>
              <div><span class="block text-[.6rem] tracking-[.2em] uppercase text-glt mb-[.15rem]">Website</span><a
                  href="https://www.risingnexusinfra.com" target="_blank"
                  class="text-white/[.72]">www.risingnexusinfra.com</a></div>
            </li>
            <li class="flex items-start gap-[.8rem] py-[.8rem] text-[.97rem]">
              <span class="text-[1.1rem] flex-shrink-0 mt-[.08rem]">🏢</span>
              <div><span class="block text-[.6rem] tracking-[.2em] uppercase text-glt mb-[.15rem]">Corporate
                  Office</span><span class="text-white/[.72]">B-743, Tower B, IThum, Sector 62, Noida, U.P.</span></div>
            </li>
          </ul>

          <!-- Quick facts -->
          <div class="border border-white/10 p-[1.4rem] mt-[1.4rem]">
            <div class="text-[.6rem] tracking-[.2em] uppercase text-glt/60 mb-[.8rem]">Project Quick Facts</div>
            <div class="grid grid-cols-2 gap-[.4rem]">
              <span class="text-[.88rem] text-white/50">📍 Barog, Dist. Solan, H.P.</span>
              <span class="text-[.88rem] text-white/50">🏗 Developer: Harison Group</span>
              <span class="text-[.88rem] text-white/50">📐 Sizes: 752–998 Sq.Ft.</span>
              <span class="text-[.88rem] text-white/50">💰 From ₹81 Lakhs*</span>
              <span class="text-[.88rem] text-white/50">🏦 SBI &amp; HDFC Approved</span>
              <span class="text-[.88rem] text-white/50">📅 Possession: Mar 2028</span>
              <span class="text-[.88rem] text-white/50">📋 RERA: HPRERASOL 2024119/P</span>
              <span class="text-[.88rem] text-white/50">🌿 AQI 32 — Excellent</span>
            </div>
          </div>
        </div>

        <!-- Form col -->
        <div>
          <form class="flex flex-col gap-[1.1rem]" id="vipForm" onsubmit="handleSubmit(event)" novalidate>
            <div>
              <label class="block text-[.65rem] tracking-[.22em] uppercase text-white/[.38] mb-[.45rem] font-semibold"
                for="f-name">Full Name *</label>
              <input type="text" id="f-name" name="name" class="vip-input" placeholder="Your full name" required />
            </div>
            <div>
              <label class="block text-[.65rem] tracking-[.22em] uppercase text-white/[.38] mb-[.45rem] font-semibold"
                for="f-wa">WhatsApp Number *</label>
              <input type="tel" id="f-wa" name="whatsapp" class="vip-input" placeholder="+91 XXXXX XXXXX" required />
            </div>
            <div>
              <label class="block text-[.65rem] tracking-[.22em] uppercase text-white/[.38] mb-[.45rem] font-semibold"
                for="f-email">Email Address</label>
              <input type="email" id="f-email" name="email" class="vip-input" placeholder="your@email.com" />
            </div>
            <div>
              <label class="block text-[.65rem] tracking-[.22em] uppercase text-white/[.38] mb-[.45rem] font-semibold"
                for="f-interest">Interested In *</label>
              <select id="f-interest" name="interest" class="vip-select" required>
                <option value="">Select your interest…</option>
                <option value="b3">Block 3 — 998 Sq.Ft. (Super Premium)</option>
                <option value="b2">Block 2 — 772 Sq.Ft. (Premium)</option>
                <option value="b1-notify">Block 1 — Notify Me When Launched</option>
                <option value="price">Official Quotation &amp; Payment Plan</option>
                <option value="visit">Site Visit Request</option>
                <option value="loan">Home Loan Assistance (SBI / HDFC)</option>
                <option value="invest">Investment Advisory</option>
              </select>
            </div>
            <div>
              <label class="block text-[.65rem] tracking-[.22em] uppercase text-white/[.38] mb-[.45rem] font-semibold"
                for="f-msg">Message (Optional)</label>
              <textarea id="f-msg" name="message" class="vip-textarea"
                placeholder="Any questions, preferred visit dates, or specific requirements…"></textarea>
            </div>
            <button type="submit"
              class="w-full py-[1.1rem] text-navy text-[.85rem] tracking-[.2em] uppercase font-bold border-none cursor-pointer hover:brightness-[1.07] transition-all duration-200 font-sans"
              style="background:linear-gradient(135deg,#B08840,#E8C97A)">
              Request Official Quotation →
            </button>
            <p class="text-[.72rem] text-white/[.28] leading-[1.6] mt-[.4rem]">100% confidential. We will only contact
              you about Harison Group Residences, Barog.</p>
          </form>

          <!-- Success state -->
          <div class="hidden text-center py-12 px-4" id="formSuccess">
            <div class="text-[3.5rem] mb-4">🏔</div>
            <h3 class="font-serif text-white mb-[.7rem]" style="font-size:2.6rem;font-weight:300">Thank You.</h3>
            <p class="text-white/[.58] leading-[1.8]">Your VIP enquiry has been received. Our concierge team will
              contact you within 24 hours with the official quotation and available inventory for Harison Group
              Residences, Barog.</p>
            <div class="mt-[.8rem] text-[.92rem] text-glt">+91 99105 87006 · sales@risingnexusinfra.com</div>
          </div>
        </div>

      </div>
    </div>
  </section>


  <!-- ════════════════════════════════════════════════════════════════════════
     FOOTER BAR
  ════════════════════════════════════════════════════════════════════════════ -->
  <?php include "include/footer.php" ?>


  <!-- ════════════════════════════════════════════════════════════════════════
     JAVASCRIPT — identical logic, no changes needed
  ════════════════════════════════════════════════════════════════════════════ -->
  <script>
    'use strict';

    function scrollTo(id) {
      const el = document.getElementById(id);
      if (el) el.scrollIntoView({
        behavior: 'smooth'
      });
    }

    /* Parallax hero */
    const heroBg = document.getElementById('heroBg');
    let ticking = false;
    window.addEventListener('scroll', () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          if (heroBg) heroBg.style.transform = `translateY(${window.scrollY * 0.34}px)`;
          ticking = false;
        });
        ticking = true;
      }
    }, {
      passive: true
    });

    /* Scroll reveal */
    const revealObs = new IntersectionObserver(
      entries => entries.forEach(e => {
        if (e.isIntersecting) e.target.classList.add('in');
      }), {
        threshold: 0.07
      }
    );
    document.querySelectorAll('.fade-up').forEach(el => revealObs.observe(el));

    /* AQI Slider */
    (function() {
      const wrap = document.getElementById('aqiWrap');
      const left = document.getElementById('aqiLeft');
      const haze = document.getElementById('aqiHaze');
      const div = document.getElementById('aqiDiv');
      const hint = document.getElementById('aqiHint');
      if (!wrap || !left || !div) return;
      let dragging = false,
        pct = 50;

      function apply(p) {
        pct = Math.max(3, Math.min(97, p));
        div.style.left = pct + '%';
        left.style.clipPath = `inset(0 ${100 - pct}% 0 0)`;
        if (haze) haze.style.clipPath = `inset(0 ${100 - pct}% 0 0)`;
      }

      function pctFromX(clientX) {
        const r = wrap.getBoundingClientRect();
        return ((clientX - r.left) / r.width) * 100;
      }
      wrap.addEventListener('mousedown', e => {
        dragging = true;
        apply(pctFromX(e.clientX));
        if (hint) hint.style.opacity = '0';
      });
      window.addEventListener('mousemove', e => {
        if (dragging) apply(pctFromX(e.clientX));
      });
      window.addEventListener('mouseup', () => {
        dragging = false;
      });
      wrap.addEventListener('touchstart', e => {
        dragging = true;
        apply(pctFromX(e.touches[0].clientX));
        if (hint) hint.style.opacity = '0';
        e.preventDefault();
      }, {
        passive: false
      });
      window.addEventListener('touchmove', e => {
        if (dragging) apply(pctFromX(e.touches[0].clientX));
      }, {
        passive: true
      });
      window.addEventListener('touchend', () => {
        dragging = false;
      });
      apply(50);
      setTimeout(() => {
        if (hint) hint.style.opacity = '0';
      }, 4000);
    })();

    /* Proximity map sidebar */
    (function() {
      const toast = document.getElementById('distToast');
      const toastName = document.getElementById('toastName');
      const toastKm = document.getElementById('toastKm');
      const toastRoute = document.getElementById('toastRoute');
      const toastClose = document.getElementById('toastClose');
      const buttons = document.querySelectorAll('.loc-btn');

      function showToast(name, km, routeUrl) {
        toastName.textContent = name;
        toastKm.textContent = km;
        toastRoute.href = routeUrl;
        toast.classList.add('show');
      }

      function hideToast() {
        toast.classList.remove('show');
        buttons.forEach(b => b.classList.remove('active'));
      }
      buttons.forEach(btn => {
        btn.addEventListener('click', () => {
          if (btn.classList.contains('active')) {
            hideToast();
            return;
          }
          buttons.forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          showToast(btn.dataset.name, btn.dataset.km, btn.dataset.route);
        });
      });
      if (toastClose) toastClose.addEventListener('click', hideToast);
    })();

    /* Floor plan tab switcher */
    function switchTab(id) {
      const keys = ['b3', 'b2', 'b1'];
      keys.forEach(k => {
        const tab = document.getElementById('tab-' + k);
        const panel = document.getElementById('panel-' + k);
        if (!tab || !panel) return;
        const isTarget = (k === id);
        // Panel
        panel.classList.toggle('active', isTarget);
        panel.style.display = isTarget ? '' : 'none';
        // Tab styling
        if (isTarget && k !== 'b1') {
          tab.classList.add('bg-navy', 'border-t-gold');
          tab.classList.remove('bg-rsrf', 'border-t-transparent');
          tab.querySelectorAll('[class*="text-navy"],[class*="text-rmuted"],[class*="text-gold"]').forEach(el => {
            if (el.dataset.label) {
              el.textContent = el.dataset.label;
            }
          });
        } else if (k !== 'b1') {
          tab.classList.remove('bg-navy', 'border-t-gold');
          tab.classList.add('bg-rsrf', 'border-t-transparent');
        }
        tab.setAttribute('aria-selected', isTarget ? 'true' : 'false');
      });
    }
    document.querySelectorAll('.p-tab').forEach(tab => {
      tab.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          tab.click();
        }
      });
    });

    /* Form submission */
    function handleSubmit(e) {
      e.preventDefault();
      const form = document.getElementById('vipForm');
      const success = document.getElementById('formSuccess');
      const name = document.getElementById('f-name').value.trim();
      const wa = document.getElementById('f-wa').value.trim();
      const interest = document.getElementById('f-interest').value;
      if (!name) {
        alert('Please enter your name.');
        return;
      }
      if (!wa) {
        alert('Please enter your WhatsApp number.');
        return;
      }
      if (!interest) {
        alert('Please select your area of interest.');
        return;
      }
      form.style.display = 'none';
      success.classList.remove('hidden');
      success.classList.add('block');
      success.scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      });
    }
  </script>

  <script>
    function site() {
      return {
        activeModal: null,
        dotsOpen: false,
        formSent: false,

        init() {
          // Scroll-reveal
          const obs = new IntersectionObserver(entries => {
            entries.forEach(e => {
              if (e.isIntersecting) e.target.classList.add('visible');
            });
          }, {
            threshold: 0.07
          });
          document.querySelectorAll('.fade-up').forEach(el => obs.observe(el));

          // ESC closes modal
          document.addEventListener('keydown', e => {
            if (e.key === 'Escape') this.closeModal();
          });
        },

        openModal(key) {
          this.dotsOpen = false;
          this.activeModal = key;
          document.body.style.overflow = 'hidden';
        },

        closeModal() {
          this.activeModal = null;
          document.body.style.overflow = '';
        },

        closeOtherDropdowns(current) {
          // Alpine handles each dropdown's own open state independently
          // This is a no-op hook for future use
        },

        handleOutsideClick(e) {
          if (!e.target.closest('#dotsWrapper')) {
            this.dotsOpen = false;
          }
        },

        handleSubmit() {
          this.formSent = true;
          setTimeout(() => {
            this.formSent = false;
          }, 5000);
        },

        downloadBrochure() {
          this.dotsOpen = false;
          alert('Brochure download coming soon.\nPlease visit www.risingnexusinfra.com for the latest materials.');
        },

        sharePage() {
          this.dotsOpen = false;
          if (navigator.share) {
            navigator.share({
              title: 'Rising Nexus Infra',
              text: 'Where Infra Connects Future & Growth',
              url: 'https://www.risingnexusinfra.com'
            });
          } else {
            navigator.clipboard.writeText('https://www.risingnexusinfra.com')
              .then(() => alert('Link copied to clipboard!'));
          }
        }
      };
    }
  </script>

</body>

</html>