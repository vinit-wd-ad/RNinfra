<footer class="bg-gray-900 py-[2.2rem] px-5 md:px-16">
    <div class="max-w-[1240px] mx-auto flex items-center justify-between flex-wrap gap-6">
        <div class="flex flex-col gap-1">
            <span class="font-sans text-[1.3rem] text-white/90 tracking-[.08em] uppercase">Rising Nexus
                Infra</span>
            <span class="text-[.63rem] text-white/35 tracking-[.1em]">© 2025 Rising Nexus Infra. All rights
                reserved.</span>
        </div>
        <nav class="flex gap-7 grid grid-cols-3 md:grid-cols-5">
            <a href="#about"
                class="text-[.63rem] tracking-[.12em] uppercase text-white/45 hover:text-white/90 no-underline transition-colors">About</a>
            <a href="#team"
                class="text-[.63rem] tracking-[.12em] uppercase text-white/45 hover:text-white/90 no-underline transition-colors">Leadership</a>
            <a href="#services"
                class="text-[.63rem] tracking-[.12em] uppercase text-white/45 hover:text-white/90 no-underline transition-colors">Services</a>
            <a href="#projects"
                class="text-[.63rem] tracking-[.12em] uppercase text-white/45 hover:text-white/90 no-underline transition-colors">Projects</a>
            <a href="#contact"
                class="text-[.63rem] tracking-[.12em] uppercase text-white/45 hover:text-white/90 no-underline transition-colors">Contact</a>
        </nav>
        <a class="text-[.72rem] text-gold no-underline hover:text-goldlt transition-colors"
            href="https://www.risingnexusinfra.com">www.risingnexusinfra.com</a>
    </div>
</footer>