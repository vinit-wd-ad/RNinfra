<nav x-data="{ mobileMenuOpen: false, dotsOpen: false }"
    class="fixed top-0 left-0 right-0 w-full z-[200] bg-white/95 backdrop-blur-md border-b border-rbdr shadow-[0_1px_24px_rgba(13,27,62,.06)]">

    <div class="flex items-center justify-between px-5 md:px-14 py-[1rem] min-w-0">

        <a href="./#home" class="flex flex-col no-underline">
            <span
                class="font-serif text-[1.1rem] md:text-[1.4rem] font-semibold tracking-[.07em] text-navy uppercase">
                <img src="assets/images/logos/logo2.png" class="w-14 md:w-20" alt="">
            </span>
        </a>

        <ul class="hidden lg:flex items-center gap-[.1rem] list-none" id="desktopNav">
            <li class="relative" x-data="{open:false, timeout:null}" @mouseenter="clearTimeout(timeout); open=true"
                @mouseleave="timeout=setTimeout(()=>open=false, 200)">
                <button @click="open=!open"
                    class="flex items-center gap-1 text-[.7rem] tracking-[.13em] uppercase text-rtxt2 hover:text-rmid px-[.9rem] py-2 bg-transparent border-none cursor-pointer font-sans transition-colors duration-200">
                    About
                    <svg class="w-2 h-2 transition-transform duration-200" :class="open?'rotate-180':''"
                        viewBox="0 0 8 5" fill="currentColor">
                        <path d="M0 0l4 5 4-5z" />
                    </svg>
                </button>
                <div class="dropdown-panel" x-show="open" x-cloak x-transition>
                    <a href="./#about"
                        class="flex items-center gap-3 px-5 py-3 text-[.68rem] tracking-[.1em] uppercase text-rtxt2 border-b border-rbdr hover:bg-rlt hover:text-rblue no-underline transition-colors"><span>🏛</span>Our Story</a>
                    <a href="./#team"
                        class="flex items-center gap-3 px-5 py-3 text-[.68rem] tracking-[.1em] uppercase text-rtxt2 border-b border-rbdr hover:bg-rlt hover:text-rblue no-underline transition-colors"><span>👥</span>Our Leadership</a>
                </div>
            </li>

            <li class="relative" x-data="{open:false, timeout:null}" @mouseenter="clearTimeout(timeout); open=true"
                @mouseleave="timeout=setTimeout(()=>open=false, 200)">
                <button @click="open=!open"
                    class="flex items-center gap-1 text-[.7rem] tracking-[.13em] uppercase text-rtxt2 hover:text-rmid px-[.9rem] py-2 bg-transparent border-none cursor-pointer font-sans transition-colors duration-200">
                    Services
                    <svg class="w-2 h-2 transition-transform duration-200" :class="open?'rotate-180':''"
                        viewBox="0 0 8 5" fill="currentColor">
                        <path d="M0 0l4 5 4-5z" />
                    </svg>
                </button>
                <div class="dropdown-panel" x-show="open" x-cloak x-transition>
                    <a href="./#services"
                        class="flex items-center gap-3 px-5 py-3 text-[.68rem] tracking-[.1em] uppercase text-rtxt2 border-b border-rbdr hover:bg-rlt hover:text-rblue no-underline transition-colors"><span>🏗</span>Real
                        Estate</a>
                    <a href="./#services"
                        class="flex items-center gap-3 px-5 py-3 text-[.68rem] tracking-[.1em] uppercase text-rtxt2 border-b border-rbdr hover:bg-rlt hover:text-rblue no-underline transition-colors"><span>⚡</span>Energy
                        Sector</a>
                    <a href="./#services"
                        class="flex items-center gap-3 px-5 py-3 text-[.68rem] tracking-[.1em] uppercase text-rtxt2 border-b border-rbdr hover:bg-rlt hover:text-rblue no-underline transition-colors">
                        <span>🖥</span>Data Centers</a>
                    <a href="./#contact"
                        class="flex items-center gap-3 px-5 py-3 text-[.68rem] tracking-[.1em] uppercase text-rtxt2 hover:bg-rlt hover:text-rblue no-underline transition-colors">
                        <span>🤝</span>Investment Opportunities</a>
                </div>
            </li>

            <li class="relative" x-data="{open:false, timeout:null}" @mouseenter="clearTimeout(timeout); open=true"
                @mouseleave="timeout=setTimeout(()=>open=false, 200)">
                <button @click="open=!open"
                    class="flex items-center gap-1 text-[.7rem] tracking-[.13em] uppercase text-rtxt2 hover:text-rmid px-[.9rem] py-2 bg-transparent border-none cursor-pointer font-sans transition-colors duration-200">
                    Projects
                    <svg class="w-2 h-2 transition-transform duration-200" :class="open?'rotate-180':''"
                        viewBox="0 0 8 5" fill="currentColor">
                        <path d="M0 0l4 5 4-5z" />
                    </svg>
                </button>
                <div class="dropdown-panel" x-show="open" x-cloak x-transition>
                    <a href="dholera.html"
                        class="flex items-center gap-3 px-5 py-3 text-[.68rem] tracking-[.1em] uppercase text-rtxt2 border-b border-rbdr hover:bg-rlt hover:text-rblue no-underline transition-colors">
                        <span>🌿</span>Dholera Smart City</a>
                    <a href="harison-barog.html"
                        class="flex items-center gap-3 px-5 py-3 text-[.68rem] tracking-[.1em] uppercase text-rtxt2 border-b border-rbdr hover:bg-rlt hover:text-rblue no-underline transition-colors">
                        <span>🏔</span>Barog, Himachal Pradesh</a>
                    <button @click="openModal('dubai');open=false"
                        class="flex items-center gap-3 w-full px-5 py-3 text-[.68rem] tracking-[.1em] uppercase text-rtxt2 border-b border-rbdr hover:bg-rlt hover:text-rblue bg-transparent border-l-0 border-r-0 border-t-0 cursor-pointer font-sans text-left transition-colors">
                        <span>🏙</span>Dubai Real Estate</button>
                    <button @click="openModal('future');open=false"
                        class="flex items-center gap-3 w-full px-5 py-3 text-[.68rem] tracking-[.1em] uppercase text-rtxt2 border-b border-rbdr hover:bg-rlt hover:text-rblue bg-transparent border-l-0 border-r-0 border-t-0 cursor-pointer font-sans text-left transition-colors">
                        <span>🔮</span>Energy &amp; Data (Upcoming)</button>
                    <a href="./#projects"
                        class="flex items-center gap-3 px-5 py-3 text-[.68rem] tracking-[.1em] uppercase text-rtxt2 hover:bg-rlt hover:text-rblue no-underline transition-colors">
                        <span>📂</span>All Projects</a>
                </div>
            </li>

            <li class="relative">
                <a href="./#contact"
                    class="flex items-center gap-3 px-5 py-3 text-[.68rem] tracking-[.1em] uppercase text-rtxt2 hover:bg-rlt hover:text-rblue no-underline transition-colors">Contact</a>
            </li>
        </ul>

        <div class="flex items-center gap-1 md:gap-4 flex-shrink-0">
            <a href="#contact"
                class="hidden sm:block text-[.6rem] md:text-[.65rem] tracking-[.16em] uppercase bg-gold text-white px-[1rem] md:px-[1.3rem] py-[.58rem] no-underline hover:bg-white hover:border-gold border-[1.5px] hover:text-navy transition-colors duration-200 font-medium">
                Enquire Now
            </a>

            <div class="relative hidden md:block" id="dotsWrapper">
                <button @click="dotsOpen=!dotsOpen"
                    class="w-9 h-9 flex flex-col items-center justify-center gap-[4px] border border-rbds bg-transparent cursor-pointer hover:border-navy transition-colors">
                    <span class="w-1 h-1 rounded-full bg-rmuted" :class="dotsOpen?'bg-navy':''"></span>
                    <span class="w-1 h-1 rounded-full bg-rmuted" :class="dotsOpen?'bg-navy':''"></span>
                    <span class="w-1 h-1 rounded-full bg-rmuted" :class="dotsOpen?'bg-navy':''"></span>
                </button>
                <div class="dots-panel" x-show="dotsOpen" x-cloak x-transition @click.away="dotsOpen = false">
                    <div
                        class="px-5 py-[.6rem] text-[.52rem] tracking-[.28em] uppercase text-rblue border-b border-rbdr font-semibold">
                        Quick Links</div>
                    <a href="./" @click="dotsOpen=false"
                        class="flex items-center gap-3 px-5 py-[.7rem] text-[.65rem] tracking-[.08em] uppercase text-rtxt2 border-b border-rbdr hover:bg-rlt hover:text-rblue no-underline transition-colors">
                        <span class="w-[18px] text-center text-[.9rem]">🏠</span>Home</a>
                    <a href="./#contact" @click="dotsOpen=false"
                        class="flex items-center gap-3 px-5 py-[.7rem] text-[.65rem] tracking-[.08em] uppercase text-rtxt2 border-b border-rbdr hover:bg-rlt hover:text-rblue no-underline transition-colors">
                        <span class="w-[18px] text-center text-[.9rem]">✉️</span>Contact Us</a>
                    <a href="https://www.risingnexusinfra.com" target="_blank"
                        class="flex items-center gap-3 px-5 py-[.7rem] text-[.65rem] tracking-[.08em] uppercase text-rtxt2 border-b border-rbdr hover:bg-rlt hover:text-rblue no-underline transition-colors">
                        <span class="w-[18px] text-center text-[.9rem]">🌐</span>Our Website</a>
                    <div class="text-[.47rem] tracking-[.24em] uppercase text-rmuted bg-rs2 px-5 py-[.42rem]">
                        Connect With Us</div>
                    <a href="https://wa.me/919910587006" target="_blank"
                        class="flex items-center gap-3 px-5 py-[.7rem] text-[.65rem] tracking-[.08em] uppercase text-rtxt2 border-b border-rbdr hover:bg-rlt hover:text-rblue no-underline transition-colors">
                        <span class="w-[18px] text-center text-[.9rem]">💬</span>WhatsApp Us</a>
                    <a href="https://www.linkedin.com/in/vast-tyagi-46a230406/" target="_blank"
                        class="flex items-center gap-3 px-5 py-[.7rem] text-[.65rem] tracking-[.08em] uppercase text-rtxt2 border-b border-rbdr hover:bg-rlt hover:text-rblue no-underline transition-colors">
                        <span class="w-[18px] text-center text-[.9rem]">🔗</span>LinkedIn</a>
                    <div class="text-[.47rem] tracking-[.24em] uppercase text-rmuted bg-rs2 px-5 py-[.42rem]">
                        Resources</div>
                    <button @click="downloadBrochure()"
                        class="flex items-center gap-3 w-full px-5 py-[.7rem] text-[.65rem] tracking-[.08em] uppercase text-rtxt2 border-b border-rbdr hover:bg-rlt hover:text-rblue bg-transparent border-l-0 border-r-0 border-t-0 cursor-pointer font-sans text-left transition-colors">
                        <span class="w-[18px] text-center text-[.9rem]">📄</span>Download Brochure</button>
                    <button @click="sharePage()"
                        class="flex items-center gap-3 w-full px-5 py-[.7rem] text-[.65rem] tracking-[.08em] uppercase text-rtxt2 hover:bg-rlt hover:text-rblue bg-transparent border-none cursor-pointer font-sans text-left transition-colors">
                        <span class="w-[18px] text-center text-[.9rem]">↗</span>Share This Page</button>
                </div>
            </div>

            <button @click="mobileMenuOpen = !mobileMenuOpen"
                class="lg:hidden w-10 h-10 flex flex-col items-center justify-center gap-[5px] border border-rbdr bg-transparent cursor-pointer">
                <span class="w-5 h-[2px] bg-navy transition-all"
                    :class="mobileMenuOpen ? 'rotate-45 translate-y-[7px]' : ''"></span>
                <span class="w-5 h-[2px] bg-navy transition-all" :class="mobileMenuOpen ? 'opacity-0' : ''"></span>
                <span class="w-5 h-[2px] bg-navy transition-all"
                    :class="mobileMenuOpen ? '-rotate-45 -translate-y-[7px]' : ''"></span>
            </button>
        </div>
    </div>

    <div x-show="mobileMenuOpen" x-cloak @click.away="mobileMenuOpen = false"
        x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0 -translate-y-4"
        x-transition:enter-end="opacity-100 translate-y-0"
        class="lg:hidden bg-white border-b border-rbdr absolute w-full left-0 shadow-xl overflow-y-auto max-h-[80vh]">

        <div class="flex flex-col p-6 space-y-4">
            <div class="text-[.55rem] tracking-[.2em] text-rmuted uppercase border-b border-gray-100 pb-2">Menu
            </div>
            <a href="./#about" @click="mobileMenuOpen = false"
                class="text-[.75rem] tracking-[.12em] uppercase text-navy no-underline py-1">About Us</a>
            <a href="./#services" @click="mobileMenuOpen = false"
                class="text-[.75rem] tracking-[.12em] uppercase text-navy no-underline py-1">Services</a>
            <a href="./#projects" @click="mobileMenuOpen = false"
                class="text-[.75rem] tracking-[.12em] uppercase text-navy no-underline py-1">Projects</a>
            <a href="./#contact" @click="mobileMenuOpen = false"
                class="text-[.75rem] tracking-[.12em] uppercase text-navy no-underline py-1">Contact</a>

            <div class="pt-4">
                <a href="./#contact" @click="mobileMenuOpen = false"
                    class="block text-center text-[.7rem] tracking-[.15em] uppercase bg-navy text-white py-3 no-underline">Enquire
                    Now</a>
            </div>
        </div>
    </div>
</nav>