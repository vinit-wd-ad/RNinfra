    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/logos/logo2.png">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,300;1,400&family=DM+Sans:wght@300;400;500;600&display=swap" />

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        navy: '#0D1B3E',
                        navy2: '#162248',
                        rblue: '#1A4DB3',
                        rmid: '#2563EB',
                        rlt: '#DBEAFE',
                        gold: '#B08840',
                        goldlt: '#E8C97A',
                        goldpal: '#FBF5E6',
                        rg: '#F5F6FA',
                        rs2: '#F0F2F8',
                        rbdr: '#E2E6F0',
                        rbds: '#C5CCE0',
                        rtxt: '#1A1F36',
                        rtxt2: '#3D4566',
                        rmuted: '#7B83A0',
                        rgreen: '#16A34A',
                        rgnpal: '#F0FDF4',
                        ramber: '#D97706',
                        rambpal: '#FFFBEB',
                        theme: '#1b3e17d6',
                    },
                    fontFamily: {
                        serif: ['"Cormorant Garamond"', 'serif'],
                        sans: ['"DM Sans"', 'sans-serif'],
                    },
                }
            }
        }
    </script>

    <!-- Alpine.js -->
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.min.css" />
    <link rel="stylesheet" href="assets/css/style.css">